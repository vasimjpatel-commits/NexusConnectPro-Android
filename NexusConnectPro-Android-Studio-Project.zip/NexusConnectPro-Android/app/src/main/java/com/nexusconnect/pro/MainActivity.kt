\
    package com.nexusconnect.pro

    import android.Manifest
    import android.app.Activity
    import android.content.Intent
    import android.content.pm.PackageManager
    import android.net.Uri
    import android.os.Bundle
    import android.webkit.GeolocationPermissions
    import android.webkit.PermissionRequest
    import android.webkit.WebChromeClient
    import android.webkit.WebResourceRequest
    import android.webkit.WebView
    import android.webkit.WebViewClient
    import android.view.ViewGroup
    import android.widget.FrameLayout
    import androidx.activity.OnBackPressedCallback
    
    class MainActivity : Activity() {
        private lateinit var webView: WebView
        private var pendingWebPermission: PermissionRequest? = null
        private var pendingGeoOrigin: String? = null
        private var pendingGeoCallback: GeolocationPermissions.Callback? = null

        companion object {
            private const val CAMERA_MIC_REQUEST = 410
            private const val LOCATION_REQUEST = 411
        }

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)

            webView = WebView(this)
            webView.layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setContentView(webView)

            webView.settings.javaScriptEnabled = true
            webView.settings.domStorageEnabled = true
            webView.settings.mediaPlaybackRequiresUserGesture = false
            webView.settings.javaScriptCanOpenWindowsAutomatically = true
            webView.settings.setSupportMultipleWindows(true)
            webView.settings.allowFileAccess = true
            webView.settings.allowContentAccess = true
            webView.settings.setGeolocationEnabled(true)

            webView.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: WebResourceRequest
                ): Boolean {
                    val url = request.url
                    val scheme = url.scheme ?: ""
                    if (scheme == "http" || scheme == "https" || scheme == "tel" || scheme == "mailto") {
                        if (url.host == "wa.me" || scheme == "tel" || scheme == "mailto") {
                            openExternal(url)
                            return true
                        }
                        if (scheme == "http") {
                            openExternal(url)
                            return true
                        }
                    }
                    return false
                }
            }

            webView.webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    runOnUiThread {
                        val wanted = request.resources.filter {
                            it == PermissionRequest.RESOURCE_VIDEO_CAPTURE ||
                            it == PermissionRequest.RESOURCE_AUDIO_CAPTURE
                        }.toTypedArray()

                        if (wanted.isEmpty()) {
                            request.deny()
                            return@runOnUiThread
                        }

                        val needsCamera = wanted.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                        val needsMic = wanted.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                        val cameraGranted = !needsCamera ||
                            checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                        val micGranted = !needsMic ||
                            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

                        if (cameraGranted && micGranted) {
                            request.grant(wanted)
                        } else {
                            pendingWebPermission?.deny()
                            pendingWebPermission = request
                            val permissions = mutableListOf<String>()
                            if (needsCamera && !cameraGranted) permissions.add(Manifest.permission.CAMERA)
                            if (needsMic && !micGranted) permissions.add(Manifest.permission.RECORD_AUDIO)
                            requestPermissions(permissions.toTypedArray(), CAMERA_MIC_REQUEST)
                        }
                    }
                }

                override fun onGeolocationPermissionsShowPrompt(
                    origin: String,
                    callback: GeolocationPermissions.Callback
                ) {
                    if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) ==
                        PackageManager.PERMISSION_GRANTED ||
                        checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) ==
                        PackageManager.PERMISSION_GRANTED
                    ) {
                        callback.invoke(origin, true, false)
                    } else {
                        pendingGeoOrigin = origin
                        pendingGeoCallback = callback
                        requestPermissions(
                            arrayOf(
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                            ),
                            LOCATION_REQUEST
                        )
                    }
                }

                override fun onCreateWindow(
                    view: WebView,
                    isDialog: Boolean,
                    isUserGesture: Boolean,
                    resultMsg: android.os.Message
                ): Boolean {
                    val popup = WebView(this@MainActivity)
                    popup.settings.javaScriptEnabled = true
                    popup.webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(
                            view: WebView,
                            request: WebResourceRequest
                        ): Boolean {
                            openExternal(request.url)
                            view.destroy()
                            return true
                        }
                    }
                    val transport = resultMsg.obj as WebView.WebViewTransport
                    transport.webView = popup
                    resultMsg.sendToTarget()
                    return true
                }
            }

            webView.loadUrl("file:///android_asset/index.html")
        }

        private fun openExternal(uri: Uri) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, uri))
            } catch (_: Exception) {
                // No compatible app installed; keep the app open.
            }
        }

        @Deprecated("Deprecated in Android, retained for runtime permission callback compatibility")
        override fun onRequestPermissionsResult(
            requestCode: Int,
            permissions: Array<out String>,
            grantResults: IntArray
        ) {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults)
            when (requestCode) {
                CAMERA_MIC_REQUEST -> {
                    val allGranted = grantResults.isNotEmpty() &&
                        grantResults.all { it == PackageManager.PERMISSION_GRANTED }
                    val request = pendingWebPermission
                    pendingWebPermission = null
                    if (allGranted && request != null) {
                        request.grant(request.resources.filter {
                            it == PermissionRequest.RESOURCE_VIDEO_CAPTURE ||
                            it == PermissionRequest.RESOURCE_AUDIO_CAPTURE
                        }.toTypedArray())
                    } else {
                        request?.deny()
                    }
                }
                LOCATION_REQUEST -> {
                    val granted =
                        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) ==
                            PackageManager.PERMISSION_GRANTED ||
                        checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) ==
                            PackageManager.PERMISSION_GRANTED
                    pendingGeoCallback?.invoke(pendingGeoOrigin ?: "", granted, false)
                    pendingGeoCallback = null
                    pendingGeoOrigin = null
                }
            }
        }

        @Suppress("DEPRECATION")
        override fun onBackPressed() {
            if (::webView.isInitialized && webView.canGoBack()) {
                webView.goBack()
            } else {
                super.onBackPressed()
            }
        }

        override fun onDestroy() {
            if (::webView.isInitialized) {
                webView.stopLoading()
                webView.destroy()
            }
            super.onDestroy()
        }
    }
